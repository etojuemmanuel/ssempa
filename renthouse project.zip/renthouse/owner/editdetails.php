<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include("navbar2.php");
        $data= $_GET["data"];
        $con= mysqli_connect("localhost", "root", "", "renthouse");
        $db= mysqli_connect("localhost", "root", "", "renthouse");
        $sql="select * from add_property where property_id='$data'";
        $result= mysqli_query($con, $sql);
        while ($rows=mysqli_fetch_assoc($result)) {
        
    ?>
     <div class="tab-pane">
      <center><h3>Edit Property Details</h3></center>
      <div class="container">

      
<div id="map_canvas"></div>
        <form method="POST" enctype="multipart/form-data">
          <div class="row">
        <div class="col-sm-6">
          <div class="form-group">
              <label for="country">Country:</label>
              <select class="form-control" name="country" required="required">
                                <option value="<?php echo $rows['country'] ?>"><?php echo $rows['country'] ?></option>
                                <option value="Uganda">Uganda</option>
                                <option value="Kenya">Kenya</option>
                                <option value="Tanzania">Tanzania</option>
              </select>
            </div>
            <div class="form-group">
              <label for="province">Province/State:</label>
              <input type="text" name="province" value="<?php echo $rows['province'] ?>" class="form-control" required="required">
              
            </div>
            <div class="form-group">
              <label for="zone">Zone:</label>
              <input type="text" name="zone" id="zone" value="<?php echo $rows['zone'] ?>" class="form-control" required="required">
              
            </div>
            <div class="form-group">
              <label for="district">District:</label>
              <input type="text" name="district" id="district" class="form-control" value="<?php echo $rows['district'] ?>" >              
            </div>
            <div class="form-group">
              <label for="city">City:</label>
              <input type="text" class="form-control" id="city" placeholder="Enter City" value="<?php echo $rows['city'] ?>" name="city">
            </div>
            <div class="form-group">
              <label for="vdc/municipality">VDC/Municipality:</label>
              <input type="text" name="vdc_municipality" id="vdc/municipality" value="<?php echo $rows['vdc/municipality'] ?>" class="form-control">
              
            </div>
            <div class="form-group">
              <label for="ward_no">Ward No.:</label>
              <input type="text" class="form-control" id="ward_no" placeholder="Enter Ward No." value="<?php echo $rows['ward_no'] ?>" name="ward_no">
            </div>
            <div class="form-group">
              <label for="tole">Tole:</label>
              <input type="text" class="form-control" id="tole" placeholder="Enter Tole" value="<?php echo $rows['tole'] ?>" name="tole">
            </div>
            <div class="form-group">
              <label for="contact_no">Contact No.:</label>
              <input type="text" class="form-control" id="contact_no" placeholder="Enter Contact No." value="<?php echo $rows['contact_no'] ?>" name="contact_no">
            </div>
        </div>

        <div class="col-sm-6">
            <div class="form-group">
               <label for="property_type">Property Type:</label>
                <select class="form-control" name="property_type">
                      <option value="<?php echo $rows['property_type'] ?>"><?php echo $rows['property_type'] ?></option>
                      <option value="Full House Rent">Full House Rent</option>
                      <option value="Flat Rent">Flat Rent</option>
                      <option value="Room Rent">Room Rent</option>
                      <option value="House Purchase">House Purchase</option>
                </select>
            </div>                      
            <div class="form-group">
                <label for="estimated_price">Estimated Price:</label>
                <input type="estimated_price" value="<?php echo $rows['estimated_price'] ?>" class="form-control" id="estimated_price" placeholder="Enter Estimated Price" name="estimated_price">
            </div>
                  <div class="form-group">
                    <label for="total_rooms">Total No. of Rooms:</label>
                    <input type="number" class="form-control" value="<?php echo $rows['total_rooms'] ?>" id="total_rooms" placeholder="Enter Total No. of Rooms" name="total_rooms">
                  </div>
                  <div class="form-group">
                    <label for="bedroom">No. of Bedroom:</label>
                    <input type="number" class="form-control" value="<?php echo $rows['bedroom'] ?>" id="bedroom" placeholder="Enter No. of Bedroom" name="bedroom">
                  </div>
                  <div class="form-group">
                    <label for="living_room">No. of Living Room:</label>
                    <input type="number" class="form-control" value="<?php echo $rows['living_room'] ?>" id="living_room" placeholder="Enter No. of Living Room" name="living_room">
                  </div>
                  <div class="form-group">
                    <label for="kitchen">No. of Kitchen:</label>
                    <input type="number" class="form-control" value="<?php echo $rows['kitchen'] ?>" id="kitchen" placeholder="Enter No. of Kitchen" name="kitchen">
                  </div>
                  <div class="form-group">
                    <label for="bathroom">No. of Bathroom/Washroom:</label>
                    <input type="number" class="form-control" value="<?php echo $rows['bathroom'] ?>" id="bathroom" placeholder="Enter No. of Bathroom/Washroom" name="bathroom">
                  </div>
                  <div class="form-group">
                    <label for="description">Full Description:</label>
                    <textarea type="comment" class="form-control" value="<?php echo $rows['description'] ?>" id="description" placeholder="Enter Property Description" name="description"></textarea>
                  </div>
                  <hr>
                  <div class="form-group">
                    <input type="submit" class="btn btn-primary btn-lg col-lg-12" value="Update Property" name="add_property">
                  </div>
                </div>
              </div>
              </form>
              <br><br>

    </div>
    </div>
    <?php
        }
        ?>
</body>
</html>