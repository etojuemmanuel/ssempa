<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    include("navbar2.php");
     include("owner-index.php");  
    $con= mysqli_connect("localhost", "root", "", "renthouse");
    $u_email=$_SESSION['email'];
    echo $_SESSION['email'];
    $sqlo="SELECT * from onwer where email='$u_email'";
    // $queryo=mysqli_query($con,$sqlo);
    // while ($ro=mysqli_fetch_assoc($queryo)) {
    //     echo $ro['owner_id'];        
    // }
    if (isset($_POST['uploade'])) {
        $file_name= $_FILES['image']['name'];
        $tempname= $_FILES['image']['tmp_name'];
        $folder ='images/'.$_FILES['image']['name'];
        $zone= $_POST['zone'];
        $country =$_POST['country'];
        $province=$_POST['province'];
        $city=$_POST['city'];
        $ward=$_POST['ward_no'];
        $tole=$_POST['tole'];
        $contact=$_POST['contact_no'];
        $property_type=$_POST['property_type'];
        $price=$_POST['estimated_price'];
        $room_no=$_POST['total_rooms'];
        $bedroom=$_POST['bedroom'];
        $livingroom=$_POST['living_room'];
        $kitchen=$_POST['kitchen'];
        $bathroom=$_POST['bathroom'];
        $description=$_POST['description'];
        $latitude=$_POST['latitude'];
        $longitude=$_POST['longitude'];
        $owner_id=$_POST['owner_id'];
        $property_id=$_POST['property_id'];
        $booked=$_POST['booked'];
        $p_photo=$_POST['p_photo'];

        $sqp="INSERT into add_property(country, zone,province, city, ward_no, tole, contact_no, property_type,estimated_price,total_rooms,
        bedroom,living_room,kitchen,bathroom, description,latitude,longitude, owner_id,property_id, booked,p_photo) 
        values('$country', '$zone' ,'$province','$city', '$ward', '$tole', '$contact', '$property_type','$price',
        '$room_no','$bedroom','$livingroom','$kitchen','$bathroom','$description','$latitude','$longitude','$owner_id','$property_id',
        '$booked','$p_photo')";
        $sql="INSERT into add_property (p_photo) values('$file_name')";
        $query= mysqli_query($con, $sql);
        $queryp= mysqli_query($con, $sqp);
        if (move_uploaded_file($tempname, $folder)) {
           echo "file uploades succesfuly";
        }else {
           echo "upload failed";
        }
        if ($queryp) {
            echo "file inserted succesfuly!";
         }else {
            echo "insertion failed";
         }
    }  
    
    ?>    
    <div  class="tab-pane ">
      <center><h3>Add Property</h3></center>
        <div class="container">      
            <div id="map_canvas"></div>
                    <form method="POST" enctype="multipart/form-data"  >
                    <div class="row">
                    <div class="col-sm-6">
                    <div class="form-group">
                        <label for="country">Country:</label>
                        <select class="form-control" name="country" required="required">                                            
                                            <option name="country" value="Uganda">Uganda</option>
                                            <option name="country" value="Tanzania">Tanzania</option>
                                            <option name="country" value="Kenya">Kenya</option>
                        </select>
                        </div>
                        <div class="form-group">
                        <label for="province">Province/Region:</label>
                        <select class="form-control" name="province" required="required">                                            
                                            <option name="province" value="Central">Central</option>
                                            <option name="province" value="Eatern Region">Eatern Region</option>
                                            <option name="province" value="Western Region">Western Region</option>
                                            <option name="province" value="Northern Region">Northern Region</option>
                                            
                        </select>
                        </div>
                        <div class="form-group">
                        <label for="zone">Zone:</label>
                        <input type="text" name="zone" id="" class="form-control" placeholder="Enter zone">
                        
                        </div>
                        <div class="form-group">
                        <label for="district">District:</label>
                        <input type="text" name="district" id="" class="form-control" placeholder="Enter district" >
                        
                        </div>
                        <div class="form-group">
                        <label for="city">City:</label>
                        <input type="text" class="form-control" id="city" placeholder="Enter City" name="city">
                        </div>
                        <div class="form-group">
                        <label for="vdc/municipality">VDC/Municipality:</label>
                        <input type="text" name="vdc_municipality" class="form-control" placeholder="Enter Municipality">
                        
                        </div>
                        <div class="form-group">
                        <label for="ward_no">Ward No.:</label>
                        <input type="text" class="form-control" id="ward_no" placeholder="Enter Ward No." name="ward_no">
                        </div>
                        <div class="form-group">
                        <label for="tole">Tole:</label>
                        <input type="text" class="form-control" id="tole" placeholder="Enter Tole" name="tole">
                        </div>
                        <div class="form-group">
                        <label for="contact_no">Contact No.:</label>
                        <input type="text" class="form-control" id="contact_no" placeholder="Enter Contact No." name="contact_no">
                        </div>
                        <div class="form-group">
                        <label for="property_type">Property Type:</label>
                            <select class="form-control" name="property_type">                                
                                <option value="Full House Rent" name="property_type">Full House Rent</option>
                                <option value="Flat Rent" name="property_type">Flat Rent</option>
                                <option value="Room Rent" name="property_type">Room Rent</option>
                                <option value="House Purchace" name="property_type">House Purchase</option>
                            </select>
                        </div>                      
                        <div class="form-group">
                            <label for="estimated_price">Estimated Price:</label>
                            <input type="estimated_price" class="form-control" id="estimated_price" placeholder="Enter Estimated Price" name="estimated_price">
                        </div>
                    </div>

                    <div class="col-sm-6">
                            <div class="form-group">
                                <label for="total_rooms">Total No. of Rooms:</label>
                                <input type="number" class="form-control" id="total_rooms" placeholder="Enter Total No. of Rooms" name="total_rooms">
                            </div>
                            <div class="form-group">
                                <label for="bedroom">No. of Bedroom:</label>
                                <input type="number" class="form-control" id="bedroom" placeholder="Enter No. of Bedroom" name="bedroom">
                            </div>
                            <div class="form-group">
                                <label for="living_room">No. of Living Room:</label>
                                <input type="number" class="form-control" id="living_room" placeholder="Enter No. of Living Room" name="living_room">
                            </div>
                            <div class="form-group">
                                <label for="kitchen">No. of Kitchen:</label>
                                <input type="number" class="form-control" id="kitchen" placeholder="Enter No. of Kitchen" name="kitchen">
                            </div>
                            <div class="form-group">
                                <label for="bathroom">No. of Bathroom/Washroom:</label>
                                <input type="number" class="form-control" id="bathroom" placeholder="Enter No. of Bathroom/Washroom" name="bathroom">
                            </div>
                            <div class="form-group">
                                <label for="description">Full Description:</label>
                                <textarea type="comment" class="form-control" id="description" placeholder="Enter Property Description" name="description"></textarea>
                            </div>
                            <table class="table table-bordered" border="0">  
                            <tr> 
                                <div class="form-group"> 
                                <label><b>Latitude/Longitude:</b><span style="color:red; font-size: 10px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; *Click on Button</span></label>                    
                                <td><input type="text" name="latitude" placeholder="Latitude" id="latitude" class="form-control name_list" readonly /></td>
                                <td><input type="text" name="longitude" placeholder="Longitude" id="longitude" class="form-control name_list" readonly /></td> 
                                <td><input type="button" value="Get Location" onclick="getLocation()" class="btn btn-success col-lg-12"></td>  
                            </div>
                            </tr>  
                            </table>
                            <table class="table" id="dynamic_field">  
                            <tr> <form action="" method="post" enctype="multipart/form-data">
                                <div class="form-group"> 
                                <label><b>Photos:</b></label>                    
                                <td><input type="file" name="p_photo" placeholder="Photos" class="form-control name_list"  accept="image/*" /></td> 
                                <td><button type="button" id="add" name="add" class="btn btn-success col-lg-12">Add More</button></td> 
                                <td><button type="submit" name="uploade" class="btn btn-success col-lg-12">upload</button></td> 
                                
                            </div>
                            </form>
                            </tr>  
                            </table>
                            <input name="lat" type="text" id="lat" hidden>
                            <input name="lng" type="text" id="lng" hidden>
                            <hr>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-lg col-lg-12" value="Add Property" name="uploade">
                            </div>
                            </div>
                        </div>
                        </form>
                        
            </div>
    </div>
    <?php
        
        $con= mysqli_connect("localhost", "root", "", "renthouse");
        if (isset($_POST['upload'])) {
            $file_name= $_FILES['p_photo']['name'];
            $tempname= $_FILES['p_photo']['tmp_name'];
            $folder ='images/'.$_FILES['p_photo']['name'];
            $sql="INSERT into add_property (p_photo) values('$file_name')";
            $query= mysqli_query($con, $sql);
            if (move_uploaded_file($tempname, $folder)) {
               echo "file uploades succesfuly";
            }else {
               echo "upload failed";
            }
           }
           $res= mysqli_query($con, "select * from add_property");
            while ($row=mysqli_fetch_assoc($res)) {
                
    ?>
        <img src="images/<?php echo $row['p_photo'] ?>" alt="" srcset="">
        <?php
        }
        $a=$_POST['country'];
        $b=$_POST['province'];
        $c=$_POST['zone'];
        $c=$_POST['district'];
        $d=$_POST['city'];
        $e=$_POST['vdc_municipality'];
        if (isset($_POST['add_propert'])) {
        $sqle="INSERT into add_property values('$a', '$b', '$c', '$d', '$e')";
        $result= mysqli_query($con,$sqle); 
        if ($result) {
            echo "connected successfully";
        }
        else {
            echo "error occured during inertion";
        }
        } 
        ?>
    
</body>
</html>