<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Real Estate Showcase</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 100%;
        overflow: hidden;
        position: relative;
    }

    .slider {
        display: flex;
        width: 300%;
        transition: transform 0.5s ease-in-out;
    }

    .slide {
        flex: 1 0 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        height: 300px; /* Adjusted slide height */
    }

    .slide img {
        max-width: 100%;
        max-height: 100%;
        object-fit: cover; /* Maintain aspect ratio */
        border-radius: 8px;
    }

    .slide-content {
        padding: 20px;
    }

    .slide:nth-child(1) { background-color: #F39C12; }
    .slide:nth-child(2) { background-color: #3498DB; }
    .slide:nth-child(3) { background-color: #27AE60; }

    .slide-title {
        font-size: 24px;
        margin-bottom: 10px;
        color: white;
    }

    .slide-description {
        font-size: 16px;
        color: white;
    }
</style>
</head>
<body>
    <div class="container">
        <div class="slider">
            <div class="slide">
                <div class="slide-content">
                    <h2 class="slide-title">Beautiful Villa</h2>
                    <p class="slide-description">Luxury villa with stunning views</p>
                    <img src="https://via.placeholder.com/600x400" alt="Villa Image">
                </div>
            </div>
            <div class="slide">
                <div class="slide-content">
                    <h2 class="slide-title">Modern Apartment</h2>
                    <p class="slide-description">Spacious apartment in the city center</p>
                    <img src="https://via.placeholder.com/600x400" alt="Apartment Image">
                </div>
            </div>
            <div class="slide">
                <div class="slide-content">
                    <h2 class="slide-title">Cozy Cottage</h2>
                    <p class="slide-description">Charming cottage surrounded by nature</p>
                    <img src="https://via.placeholder.com/600x400" alt="Cottage Image">
                </div>
            </div>
        </div>
    </div>
    <button onclick="slideLeft()">Previous Property</button>
    <button onclick="slideRight()">Next Property</button>

    <script>
        let currentSlide = 0;
        const totalSlides = document.querySelectorAll('.slide').length;

        function slideLeft() {
            currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
            updateSliderPosition();
        }

        function slideRight() {
            currentSlide = (currentSlide + 1) % totalSlides;
            updateSliderPosition();
        }

        function updateSliderPosition() {
            const slider = document.querySelector('.slider');
            const slideWidth = document.querySelector('.slide').clientWidth;
            const newPosition = -currentSlide * slideWidth;
            slider.style.transform = `translateX(${newPosition}px)`;
        }
    </script>
</body>
</html>
