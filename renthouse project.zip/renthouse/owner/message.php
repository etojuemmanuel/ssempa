<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="fashion.css">
    <title>Document</title>
</head>
<body>
<?php
    include("navbar2.php");
?>

<div id="menu4" class="tab-pane ">
      <?php 
          $owner_id=$rows['owner_id']; 
          $sql1="SELECT * FROM chat where owner_id='$owner_id' ";
          $query1 = mysqli_query($db,$sql1);
          $tenant_id=$row['tenant_id'];
          $sql2="SELECT * FROM tenant where tenant_id='$tenant_id' ";
          $query2 = mysqli_query($db,$sql2);

            if(mysqli_num_rows($query1)>0)
            {
              ?>
                <div class="container">
                  <h4>messages!</h4>
                  <?php
              while($row= mysqli_fetch_assoc($query1)){
                ?>
                  <div class="tweet-card">
                  <div class="user-info">
                    <img src="<?php echo $row['id_photo']?>" alt="Profile Picture">
                    <div class="user-details"> 
                      <h3>Name: <?php echo $row['full_name']?></h3>
                      <p>username: @<?php echo $row['full_name']?>  Date: <?php echo $row['date']?></p>
                    </div>
                  </div>
                  <p class="tweet-text"><?php echo $row['message']?></p>
                  <div class="tweet-actions">
                    <a href="#">Reply</a>                    
                  </div>
                </div>
                </div>   
                <?php            

            if(mysqli_num_rows($query2)>0)
            {?>
                <div class="container">
                  <h4>messages!</h4>
                  <?php
              while($row= mysqli_fetch_assoc($query2)){
                ?>
                  <div class="tweet-card">
                  <div class="user-info">
                    <img src="<?php echo $row['id_photo']?>" alt="Profile Picture">
                    <div class="user-details">
                      <h3>Name: <?php echo $row['full_name']?></h3>
                      <p>Email: <?php echo $row['email']?>  Date: <?php echo $row['date']?></p>
                    </div>
                  </div>
                  <p class="tweet-text"><?php echo $row['message']?></p>
                  <div class="tweet-actions">
                    <a href="#">Reply</a>                    
                  </div>
                </div>
                </div>   
                <?php 
              
      ?>
      <div class="container">
            <link rel="stylesheet" type="text/css" href="message-style.css">

            <div class="tab">   
              <button class="tablinks" id="defaultOpen" ><?php echo $rows["full_name"]; ?></button>
            </div>

            <div id="<?php echo $rows["full_name"]; ?>" class="tabcontent">
              <?php
              $sql3="SELECT * FROM chat where tenant_id='$tenant_id' AND owner_id='$owner_id' ";

                $query3 = mysqli_query($db,$sql3);

              if(mysqli_num_rows($query3)>0)
              {
                while($ro= mysqli_fetch_assoc($query3)){
                  echo $ro["message"]."<br>";
                }}
              ?>
</div>

<?php
        //echo '<a href="send-message.php?owner_id='.$owner_id.'&tenant_id='.$tenant_id.'">'.$rows["full_name"].'</a>';
    }
  }}}?>
    </div>
    </div>
</body>
</html>