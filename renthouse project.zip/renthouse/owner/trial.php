<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $con= mysqli_connect("localhost", "root", "", "renthouse");
    $u_email=$_SESSION['email'];
    echo $_SESSION['email'];
    $sqlo="SELECT * from onwer where email='$u_email'";
    // $queryo=mysqli_query($con,$sqlo);
    // while ($ro=mysqli_fetch_assoc($queryo)) {
    //     echo $ro['owner_id'];        
    // }
    if (isset($_POST['upload'])) {
        $file_name= $_FILES['image']['name'];
        $tempname= $_FILES['image']['tmp_name'];
        $folder ='images/'.$_FILES['image']['name'];
        $zone= $_POST['zone'];
        $country =$_POST['country'];
        $province=$_POST['province'];
        $city=$_POST['city'];
        $ward=$_POST['ward_no'];
        $tole=$_POST['tole'];
        $contact=$_POST['contact_no'];
        $property_type=$_POST['property_type'];
        $price=$_POST['estimated_price'];
        $room_no=$_POST['total_rooms'];
        $bedroom=$_POST['bedroom'];
        $livingroom=$_POST['living_room'];
        $kitchen=$_POST['kitchen'];
        $bathroom=$_POST['bathroom'];
        $description=$_POST['description'];
        $latitude=$_POST['latitude'];
        $longitude=$_POST['longitude'];
        $owner_id=$_POST['owner_id'];
        $property_id=$_POST['property_id'];
        $booked=$_POST['booked'];
        $p_photo=$_POST['p_photo'];

        $sqp="INSERT into add_property(country, zone,province, city, ward_no, tole, contact_no, property_type,estimated_price,total_rooms,
        bedroom,living_room,kitchen,bathroom, description,latitude,longitude, owner_id,property_id, booked,p_photo) 
        values('$country', '$zone' ,'$province','$city', '$ward', '$tole', '$contact', '$property_type','$price',
        '$room_no','$bedroom','$livingroom','$kitchen','$bathroom','$description','$latitude','$longitude','$owner_id','$property_id',
        '$booked','$p_photo')";
        $sql="INSERT into add_property (p_photo) values('$file_name')";
        $query= mysqli_query($con, $sql);
        $queryp= mysqli_query($con, $sqp);
        if (move_uploaded_file($tempname, $folder)) {
           echo "file uploades succesfuly";
        }else {
           echo "upload failed";
        }
        if ($queryp) {
            echo "file inserted succesfuly!";
         }else {
            echo "insertion failed";
         }
       }
       ?>
    <form action="" method="post" enctype="multipart/form-data">
        zone<input type="text" name="zone" id=""><br><br>
        country<input type="text" name="country" id=""><br><br>
        province<input type="text" name="province" id="" ><br><br>
        image<input type="file" name="image" id=""><br><br>
        city<input type="text" name="city" id=""><br><br>
        ward<input type="text" name="ward_no" id=""><br><br>
        tole<input type="text" name="tole" id=""><br><br>
        contact<input type="text" name="contact_no" id=""><br><br>
        property type<input type="text" name="property_type" id=""><br><br>
       price<input type="text" name="estimated_price" id=""><br><br>
       Room no<input type="text" name="total_rooms" id=""><br><br>
        bedrooms<input type="text" name="bedroom" id=""><br><br>
        living room<input type="text" name="living_room" id="" ><br><br>
        kitchen<input type="text" name="kitchen" id=""><br><br>
        bathroom<input type="text" name="bathroom" id=""><br><br>
        description<input type="text" name="description" id="" value="<?php echo $ro['owner_id']?>"><br><br>
        latitude<input type="text" name="latitude" id=""><br><br>
        longitude<input type="text" name="longitude" id=""><br><br>
        owner_id<input type="text" name="owner_id" id=""><br><br>
        property_id<input type="text" name="property_id" id=""><br><br>
        <input type="text" name="booked" id="">
        <input type="file" name="p_photo" id="" hidden>
        <input type="submit" value="upload" name="upload">
    </form>
    <?php
        while ($rows=mysqli_fetch_assoc($res)) {
            # code...
        }
        $res= mysqli_query($con, "select * from add_property");
        while ($row=mysqli_fetch_assoc($res)) {
                
    ?>
    
        <img src="images/<?php echo $row['p_photo'] ?>" alt="" srcset="">
        <h1>zone:   <?php echo $row['zone'] ?></h1>
        <h1>country:    <?php echo $row['country'] ?></h1>
        <h1>province:   <?php echo $row['province'] ?></h1>
        <h1>city:   <?php echo $row['city'] ?></h1>
        <h1>ward: <?php echo $row['ward_no'] ?></h1>
        <h1>tole:   <?php echo $row['tole'] ?></h1>
        <h1>conatact: <?php echo $row['contact_no'] ?></h1>
        <h1>property type:  <?php echo $row['property_type'] ?></h1>
        <h1>pric  <?php echo $row['estimated_price'] ?></h1>
        <h1>room no:   <?php echo $row['total_rooms'] ?></h1>
        <h1>living room:    <?php echo $row['living_room'] ?></h1>
        <h1>kitchen:    <?php echo $row['kitchen'] ?></h1>
        <h1>bathroom:   <?php echo $row['bathroom'] ?></h1>
        <h1>description:   <?php echo $row['description'] ?></h1>
        <h1>lat: <?php echo $row['latitude'] ?></h1>
        <h1>long:   <?php echo $row['longitude'] ?></h1>
        <h1>owner: <?php echo $row['owner_id'] ?></h1>
        <h1>property ID:  <?php echo $row['property_id'] ?></h1>
        <h1>booked:  <?php echo $row['booked'] ?></h1>
         photo<input type="file" name="P_photo" id="">
        <?php
        }
    ?>
</body>
</html>