<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Real Estate Showcase</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 100%;
        overflow-x: auto;
        white-space: nowrap;
        border: 1px solid #ccc;
        position: relative; /* Added for navigation buttons */
    }

    .slider {
        display: inline-flex;
    }

    .slide {
        width: 300px;
        height: 300px;
        display: inline-block;
        margin-right: 20px;
        text-align: center;
        vertical-align: top;
    }

    .slide img {
        max-width: 100%;
        max-height: 100%;
        object-fit: cover;
        border-radius: 8px;
    }

    .slide-content {
        padding: 20px;
    }

    .slide-title {
        font-size: 24px;
        margin-bottom: 10px;
        color: white;
    }

    .slide-description {
        font-size: 16px;
        color: white;
    }

    /* Style for navigation buttons */
    .prev, .next {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background-color: rgba(255, 255, 255, 0.5);
        color: black;
        padding: 10px;
        border: none;
        cursor: pointer;
    }

    .prev {
        left: 10px;
    }

    .next {
        right: 10px;
    }
</style>
</head>
<body>
    <div class="container">
        <div class="slider">
            <div class="slide">
                <div class="slide-content" style="background-color: #F39C12;">
                    <h2 class="slide-title">Beautiful Villa</h2>
                    <p class="slide-description">Luxury villa with stunning views</p>
                    <img src="https://via.placeholder.com/600x400" alt="Villa Image">
                </div>
            </div>
            <div class="slide">
                <div class="slide-content" style="background-color: #3498DB;">
                    <h2 class="slide-title">Modern Apartment</h2>
                    <p class="slide-description">Spacious apartment in the city center</p>
                    <img src="https://via.placeholder.com/600x400" alt="Apartment Image">
                </div>
            </div>
            <div class="slide">
                <div class="slide-content" style="background-color: #27AE60;">
                    <h2 class="slide-title">Cozy Cottage</h2>
                    <p class="slide-description">Charming cottage surrounded by nature</p>
                    <img src="https://via.placeholder.com/600x400" alt="Cottage Image">
                </div>
            </div>
            <!-- Add more slides as needed -->
        </div>
        <button class="prev" onclick="prevSlide()">Previous</button>
        <button class="next" onclick="nextSlide()">Next</button>
    </div>

    <script>
        let slideIndex = 0;
        const slides = document.querySelectorAll('.slide');
        
        function showSlides() {
            slides.forEach(slide => {
                slide.style.display = 'none';
            });
            slides[slideIndex].style.display = 'block';
        }
        
        function nextSlide() {
            slideIndex++;
            if (slideIndex >= slides.length) {
                slideIndex = 0;
            }
            showSlides();
        }
        
        function prevSlide() {
            slideIndex--;
            if (slideIndex < 0) {
                slideIndex = slides.length - 1;
            }
            showSlides();
        }
        
        // Automatic slideshow
        setInterval(nextSlide, 5000);
        
        // Initial slide display
        showSlides();
    </script>
</body>
</html>
