<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="scrol.css">
</head>
<body>
    
    <div class="wraper ">
        <div class="items">        
            <img src="Esther .jpg" alt="" srcset="" class="image">        
            <div class="lists">
                <p class="title">short title</p>
                <p class="title">short title</p>
                <button type="button">View property</button>
                
            </div>       
        </div>        
    </div>
    
</body>
</html>