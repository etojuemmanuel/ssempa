<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<title>Real Estate Showcase</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 100%;
        overflow-x: auto;
        overflow-y: auto; /* Allow horizontal scrolling */
        white-space: nowrap; /* Prevent slides from wrapping */
        border: 2px solid black;
        border-radius: 10px;

    }

    .slider {
        display: inline-flex; /* Display slides in a row */
    }

    .slide {
        width: 300px; /* Adjust slide width as needed */
        height: 300px; /* Adjust slide height as needed */
        display: inline-block;
        margin-right: 20px; /* Space between slides */
        text-align: center;
        vertical-align: top;
        border-radius: 10px;
    }

    .slide img {
        max-width: 100%;
        max-height: 100%;
        object-fit: cover; /* Maintain aspect ratio */
        border-radius: 10px;
    }

    .slide-content {
        padding: 10px;
        border-radius: 10px;
    }

    .slide-title {
        font-size: 24px;
        margin-bottom: 10px;
        color: white;
    }

    .slide-description {
        font-size: 16px;
        color: white;
    }
</style>
</head>
<body>
    <?php
    $con= mysqli_connect("localhost", "root", "", "renthouse");
    $sql="Select * from add_property where property_type='Full House Rent'";
    $result =mysqli_query($con, $sql);
    while ($row=mysqli_fetch_assoc($result)) {
        
    
    ?>
    <div class="container">
        <div class="slider">
            <div class="slide">
                <div class="slide-content" style="background-color: #F39C12;">
                    <h4 class="slide-title"><?php echo $row['property_type']?></h4>
                    <!-- <img src="<?php echo $row['p_photo']?>" alt="Villa Image"> -->
                    <img src="https://via.placeholder.com/600x400" alt="Villa Image">
                    <p class="slide-description">Location:  <?php echo $row['city']?>, <?php echo $row['district']?>, <?php echo $row['province']?> </p>
                    <p class="slide-description">No Rooms: <?php echo $row['total_rooms']?>, Price:  <?php echo $row['estimated_price']?></p>
                    <p><a href="view-property.php?data=<?php echo $rows['property_id']?>"  class="btn btn-lg btn-primary btn-block" >View Property </a><br>'; </p>
                </div>
            </div>
            <div class="slide">
                <div class="slide-content" style="background-color: #3498DB;">
                    <h2 class="slide-title">Modern Apartment</h2>
                    <p class="slide-description">Spacious apartment in the city center</p>
                    <img src="https://via.placeholder.com/600x400" alt="Apartment Image">
                </div>
            </div>
            <div class="slide">
                <div class="slide-content" style="background-color: #27AE60;">
                    <h2 class="slide-title">Cozy Cottage</h2>
                    <p class="slide-description">Charming cottage surrounded by nature</p>
                    <img src="https://via.placeholder.com/600x400" alt="Cottage Image">
                </div>
            </div>
            <div class="slide">
                <div class="slide-content" style="background-color: #27AE60;">
                    <h2 class="slide-title">Cozy Cottage</h2>
                    <p class="slide-description">Charming cottage surrounded by nature</p>
                    <img src="https://via.placeholder.com/600x400" alt="Cottage Image">
                </div>
            </div>
            <div class="slide">
                <div class="slide-content" style="background-color: #27AE60;">
                    <h2 class="slide-title">Cozy Cottage</h2>
                    <p class="slide-description">Charming cottage surrounded by nature</p>
                    <img src="https://via.placeholder.com/600x400" alt="Cottage Image">
                </div>
            </div>
            <div class="slide">
                <div class="slide-content" style="background-color: #27AE60;">
                    <h2 class="slide-title">Cozy Cottage</h2>
                    <p class="slide-description">Charming cottage surrounded by nature</p>
                    <img src="https://via.placeholder.com/600x400" alt="Cottage Image">
                </div>
            </div>
            <!-- Add more slides as needed -->
        </div>
    </div>

    <script>
        // JavaScript can be added here for any dynamic functionality if needed
    </script>
    <?php
    }
    ?>
</body>
</html>
