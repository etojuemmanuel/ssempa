<?php 
session_start();

include("navbar.php");

 ?> 
<div class="bg"></div><br>
<link rel="stylesheet" href="scrol.css">
<div class="container active-cyan-4 mb-4 inline">
	<form method="POST" action="search-property.php">
  <input class="formcontrol" type="text" placeholder="Enter location to search house." name="search_property" aria-label="Search" >
  <input class="btnn" type="submit" value="Search">
  </form>
</div>


<?php 
  include("config/config.php");
    // include("property-list.php");
    $slqp="SELECT * from Add_property where property_type='Full House Rent'";
    $queryp= mysqli_query($db,$slqp);
    if (mysqli_num_rows($queryp)>0) {
      ?><h2>Houses for Rent</h2><?php
      while ($row=mysqli_fetch_assoc($queryp)) {
        $proerty_id=$row['property_id'];
        $sqlpp="SELECT * from property_photo WHERE property_id='$proerty_id'";
        $pquery=mysqli_query($db,$sqlpp);
        while ($rows=mysqli_fetch_assoc($pquery)) {
          ?>
          <div class="wraper">
            <div class="image">
              <img src="<?php echo $rows['p_photo']?>" alt="" class="image">
            </div>          
        <?php
        }
        ?>
        <div class="items">
          <p>City: <?php echo $row['city']?>, District: <?php echo $row['district']?> </p>
          <p>Room No: <?php echo $row['total_rooms']?>, Price: <?php echo $row['estimated_price']?></p>
          <p><a href="view-property.php?data=<?php echo $rows['property_id']?>"  class="btn btn-sht btn-primary">View Property </a>
        </div>
        </div>
        <?php        
      }
    }

?>

