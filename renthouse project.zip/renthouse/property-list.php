<?php 
include("config/config.php");
 ?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="property-list.css">
<link rel="stylesheet" href="scrol.css">
<link rel="stylesheet" href="homeindex.css">
</head>
<body>
<?php 

$sql="SELECT * FROM add_property";
    $query=mysqli_query($db,$sql);

    if(mysqli_num_rows($query)>0)
    {
      while ($rows=mysqli_fetch_assoc($query)) {
        $property_id=$rows['property_id'];
        $sql2="SELECT * FROM property_photo where property_id='$property_id'";
        $query2=mysqli_query($db,$sql2);

?>

<div class="col-sm-2">
<div class="card">
<?php


    if(mysqli_num_rows($query2)>0)
    {
      $row=mysqli_fetch_assoc($query2);
      ?>
      <!-- <div class="card">
        <div class="card-body">
          <?php
          $photo=$row['p_photo'];
          echo  '<img class="image" src="owner/'.$photo.'">'; }?>
        
          <div class="card_detail">
          <h4><b><?php echo $rows['property_type']; ?></b></h4> 
          </div>
          <div class="card_detail">
            <p>Location: <?php echo $rows['vdc_municipality'].', '.$rows['district'].', '.$rows['city'] ?></p>
          </div>
          <div class="card_detail">
            <p>Tell:  <?php echo $rows['contact_no']?></p>            
          </div>
          <div class="card_detail">
            <p>Room No: <?php echo $rows['total_rooms'].',   Price: '.$rows['estimated_price'] ?></p> 
          </div>
          <div class="card_detail">
            <p><a href="view-property.php?data=<?php echo $rows['property_id']?>"  class="btn btn-lg btn-primary btn-block" >View Property </a><br>'; </p><br>
          </div>
        </div>
      </div> -->
      <div class="wraper ">
        <div class="items">
        <?php
          $photo=$row['p_photo'];
          echo  '<img class="image" src="owner/'.$photo.'">'; }?>          
               
            <div class="lists">
                <div class="card_detail">
                <h4><b><?php echo $rows['property_type']; ?></b></h4> 
                </div>
                <div class="card_detail">
                    <p>Location: <?php echo $rows['vdc_municipality'].', '.$rows['district'].', '.$rows['city'] ?></p>
                </div>
                <div class="card_detail">
                    <p>Tell:  <?php echo $rows['contact_no']?></p>            
                </div>
                <div class="card_detail">
                    <p>Room No: <?php echo $rows['total_rooms'].',   Price: '.$rows['estimated_price'] ?></p> 
                </div>
                <div class="card_detail">
                    <p><a href="view-property.php?data=<?php echo $rows['property_id']?>"  class="btn btn-lg btn-primary btn-block" >View Property </a><br>'; </p><br>
                </div>
            </div>       
        </div>        
    </div>
  </div>
</div>
<!-- the start of the second trial demo commented below -->
<!-- <header class="page_header">
  <div class="container flow">
    <h1 class="page_title">Horizontal scalling</h1>
    <p class="page_subtitle">lets do this shit</p>
  </div>
</header>
<h2 class="section_title">Individual elements</h2>
<div class="media_scroll">
  <div class="media_scroll_elements ">
    <img src="" alt="" srcset="">
    <p class="title">short title</p>
  </div>
  <div class="media_scroll_elements"></div>
  <div class="media_scroll_elements"></div>
  <div class="media_scroll_elements"></div>
  <div class="media_scroll_elements"></div>
  <div class="media_scroll_elements"></div>
  <div class="media_scroll_elements"></div>
  <div class="media_scroll_elements"></div>
</div> -->

</body>
</html> 


<?php 

}
?>