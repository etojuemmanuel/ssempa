<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="property-list.css">
</head>
<body>
<header class="page_header">
  <div class="container flow">
    <h1 class="page_title">Horizontal scalling</h1>
    <p class="page_subtitle">lets do this shit</p>
  </div>
</header>
<h2 class="section_title">Individual elements</h2>
<div class="media_scroll">
  <div class="media_scroll_elements snaps_inline">
    <img src="Esther.jpg" alt="" srcset="">
    <p class="title">short title</p>
  </div>
  <div class="media_scroll_elements snaps_inline">
    <img src="Esther.jpg" alt="" srcset="">
    <p class="title">short title</p>
  </div>
  <div class="media_scroll_elements snaps_inline">
    <img src="Esther.jpg" alt="" srcset="">
    <p class="title">short title</p>
  </div>
  <div class="media_scroll_elements snaps_inline">
    <img src="Esther.jpg" alt="" srcset="">
    <p class="title">short title</p>
  </div>
  <div class="media_scroll_elements snaps_inline">
    <img src="Esther.jpg" alt="" srcset="">
    <p class="title">short title</p>
  </div>
  <div class="media_scroll_elements snaps_inline">
    <img src="Esther.jpg" alt="" srcset="">
    <p class="title">short title</p>
  </div>
</div>
</body>
</html>